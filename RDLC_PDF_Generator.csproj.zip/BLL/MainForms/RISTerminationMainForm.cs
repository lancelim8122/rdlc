﻿using Microsoft.Reporting.WebForms;
using  RDLC_PDF_Generator.Datasets;
using  RDLC_PDF_Generator.Datasets.WMSDataSetTableAdapters;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace  RDLC_PDF_Generator.BLL.MainForms
{
    public class RISTerminationMainForm
    {
        public void formRISTerminationMainForm(string SPVRequestId, DataTable dtCustomer, ReportViewer rv, int sectionNo)
        {
            rv.LocalReport.DisplayName = "ut_form_ris_termination";
            rv.LocalReport.ReportPath = Path.Combine("RDLC", rv.LocalReport.DisplayName + ".rdlc");

            rv.LocalReport.SetParameters(new ReportParameter("FundName", "Test Fund Name")); // To be replaced and should be mapped from DRIM/UTFundProduct

            #region section number assignation
            sectionNo++;
            rv.LocalReport.SetParameters(new ReportParameter("declaration_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.LocalReport.SetParameters(new ReportParameter("agreement_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.LocalReport.SetParameters(new ReportParameter("terms_and_cond_SecNo", sectionNo.ToString()));
            #endregion section number assignation

            #region Sub-reports
            var subReports = new SubReportService(SPVRequestId, dtCustomer);
            rv.LocalReport.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetFormManageDivInsSubDataSource);
            #endregion Sub-reports
        }
    }
}
