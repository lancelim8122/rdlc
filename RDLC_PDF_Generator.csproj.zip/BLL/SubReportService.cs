﻿using Microsoft.Reporting.WebForms;
using  RDLC_PDF_Generator.Datasets;
using  RDLC_PDF_Generator.Datasets.WMSDataSetTableAdapters;
using System;
using System.Data;
using System.IO;
using System.Linq;

namespace  RDLC_PDF_Generator.BLL
{
    public class SubReportService
    {
        string RequestId;
        DataTable dtCustomer = new WMSDataSet().ds_agreement_signature.Copy();
        DataTable ds_StaticContent = new UTOrderFormStaticContentTableAdapter().GetData();

        public SubReportService(string mainRequestId, DataTable mainDtCustomer)
        {
            RequestId = mainRequestId;
            dtCustomer = mainDtCustomer;
        }

        public void SetAgreementSignSubDataSource(object sender, SubreportProcessingEventArgs e)
        {
            if (dtCustomer != null && dtCustomer.Rows.Count > 0)
            {
                e.DataSources.Add(new ReportDataSource
                {
                    Name = "ds_agreement_signature",
                    Value = dtCustomer
                });
            }

            var dt_bankOfficer = new DataTable();
            dt_bankOfficer.Columns.Add("BranchName");
            dt_bankOfficer.Columns.Add("BranchCode");
            dt_bankOfficer.Columns.Add("AdvisedBy");
            dt_bankOfficer.Columns.Add("SalesAgentCode");

            #region test data
            var dr = dt_bankOfficer.NewRow();
            dr["BranchName"] = "Test Branch Name";
            dr["BranchCode"] = "Test Branch Code";
            dr["AdvisedBy"] = "Test Advised By";
            dr["SalesAgentCode"] = "Test Sales Agent Code";
            #endregion test data

            dt_bankOfficer.Rows.Add(dr);

            e.DataSources.Add(new ReportDataSource
            {
                Name = "ds_agreement_bankOfficer",
                Value = dt_bankOfficer
            });

            e.DataSources.Add(new ReportDataSource
            {
                Name = "ds_StaticContent",
                Value = ds_StaticContent
            });
        }

        public void SetFormManageDivInsSubDataSource(object sender, SubreportProcessingEventArgs e)
        {
            var ds = new ds_ut_sub_dividendTableAdapter().GetData(RequestId);
            if (ds != null && ds.Rows.Count > 0)
            {
                e.DataSources.Add(new ReportDataSource
                {
                    Name = "ds_prc_ut_sub_dividend",
                    Value = ds.CopyToDataTable()
                });
            }

            e.DataSources.Add(new ReportDataSource
            {
                Name = "ds_StaticContent",
                Value = ds_StaticContent
            });
        }

        public void SetFormSubCancellationSubDataSource(object sender, SubreportProcessingEventArgs e)
        {
            var ds = new ds_ut_sub_cancellationTableAdapter().GetData(RequestId).CopyToDataTable();
            if (ds != null && ds.Rows.Count > 0)
            {
                e.DataSources.Add(new ReportDataSource
                {
                    Name = "ds_prc_sub_cancellation",
                    Value = ds
                });
            }
        }

        public void SetAddDeclarationSubDataSource(object sender, SubreportProcessingEventArgs e)
        {
            e.DataSources.Add(new ReportDataSource
            {
                Name = "ds_StaticContent",
                Value = ds_StaticContent
            });
        }

        public void SetCPFSubDataSource(object sender, SubreportProcessingEventArgs e)
        {
            e.DataSources.Add(new ReportDataSource
            {
                Name = "ds_StaticContent",
                Value = ds_StaticContent
            });
        }

        public void SetDeclarationSubDataSource(object sender, SubreportProcessingEventArgs e)
        {
            e.DataSources.Add(new ReportDataSource
            {
                Name = "ds_StaticContent",
                Value = ds_StaticContent
            });
        }

        public void SetImpNoticeSwitchingSubDataSource(object sender, SubreportProcessingEventArgs e)
        {
            e.DataSources.Add(new ReportDataSource
            {
                Name = "ds_StaticContent",
                Value = ds_StaticContent
            });
        }

        public void SetTNCSubDataSource(object sender, SubreportProcessingEventArgs e)
        {
            e.DataSources.Add(new ReportDataSource
            {
                Name = "ds_StaticContent",
                Value = ds_StaticContent
            });
        }

        #region for testing purpose
        public ReportViewer formSubAdditionalDeclaration()
        {
            var add_decl_text = string.Empty;
            var cbImgUrl = Path.Combine(@"file:///" + Environment.CurrentDirectory, "Image", "Checked.jpg");

            ReportViewer rv = new ReportViewer();
            rv.LocalReport.EnableExternalImages = true;
            rv.LocalReport.DisplayName = "ut_sub_add_declaration";
            rv.LocalReport.ReportPath = Path.Combine("RDLC", "Sub-Reports", rv.LocalReport.DisplayName + ".rdlc");
            var ds = new UTOrderFormStaticContentTableAdapter().GetData();
            if (ds.Rows.Count > 0)
            {
                add_decl_text = ds
                    .Where(x =>
                        x.FormSection.Equals("ADD_DECL_FOR_SUBS_AND_SWT") &&
                        x.IndexNo.Equals("00010"))
                    .Select(x => x.Text)
                    .FirstOrDefault();

                rv.LocalReport.DataSources.Add(new ReportDataSource
                {
                    Name = "DataSet1",
                    Value = ds
                });
            }

            rv.LocalReport.SetParameters(new ReportParameter("Add_Decl_Text", add_decl_text));
            rv.LocalReport.SetParameters(new ReportParameter("CheckBoxImgUrl", cbImgUrl));
            rv.LocalReport.Refresh();
            return rv;
        }

        public ReportViewer formSubAgreement()
        {
            var Agreement_Text = string.Empty;
            var ds = new UTOrderFormStaticContentTableAdapter().GetData();
            if (ds != null && ds.Rows.Count > 0)
            {
                Agreement_Text = ds
                    .Where(x =>
                        x.FormSection.Equals("AGREEMENT") &&
                        x.IndexNo.Equals("00010"))
                    .Select(x => x.Text)
                    .FirstOrDefault();
            }

            ReportViewer rv = new ReportViewer();
            rv.LocalReport.DisplayName = "ut_sub_agreement";
            rv.LocalReport.ReportPath = Path.Combine("RDLC", "Sub-Reports", rv.LocalReport.DisplayName + ".rdlc");
            rv.LocalReport.SetParameters(new ReportParameter("Agreement_Text", Agreement_Text));
            rv.LocalReport.Refresh();
            return rv;
        }

        public ReportViewer formSubCancellation(string SPVRequestOrderId)
        {
            ReportViewer rv = new ReportViewer();
            rv.LocalReport.DisplayName = "ut_sub_cancellation";
            rv.LocalReport.ReportPath = Path.Combine("RDLC", "Sub-Reports", rv.LocalReport.DisplayName + ".rdlc");
            rv.LocalReport.SetParameters(new ReportParameter("FundName", "Test Fund Name"));

            var ds = new ds_ut_sub_cancellationTableAdapter().GetData(SPVRequestOrderId).CopyToDataTable();
            if (ds != null && ds.Rows.Count > 0)
            {
                var data = new ReportDataSource
                {
                    Name = "ds_prc_sub_cancellation",
                    Value = ds
                };
                rv.LocalReport.DataSources.Add(data);
            }

            rv.LocalReport.Refresh();
            return rv;
        }

        public ReportViewer formSubCPF()
        {
            ReportViewer rv = new ReportViewer();
            rv.LocalReport.DisplayName = "ut_sub_cpf";
            rv.LocalReport.ReportPath = Path.Combine("RDLC", "Sub-Reports", rv.LocalReport.DisplayName + ".rdlc");
            var ds = new UTOrderFormStaticContentTableAdapter().GetData();
            if (ds.Rows.Count > 0)
            {
                var CPFText = ds
                    .Where(x =>
                        x.FormSection.Equals("IMPT_NOTE_CPFIS_SAQ") &&
                        x.IndexNo.Equals("00010"))
                    .Select(x => x.Text)
                    .FirstOrDefault();

                rv.LocalReport.SetParameters(new ReportParameter("IMPT_NOTE_CPFIS_SAQ_Text", CPFText));
            }
            rv.LocalReport.Refresh();
            return rv;
        }

        public ReportViewer formSubDeclaration()
        {
            ReportViewer rv = new ReportViewer();
            rv.LocalReport.DisplayName = "ut_sub_declaration";
            rv.LocalReport.ReportPath = Path.Combine("RDLC", "Sub-Reports", rv.LocalReport.DisplayName + ".rdlc");
            var ds = new UTOrderFormStaticContentTableAdapter().GetData();
            if (ds.Rows.Count > 0)
            {
                var DeclText = ds
                    .Where(x =>
                        x.FormSection.Equals("DECLARATION") &&
                        x.IndexNo.Equals("00010"))
                    .Select(x => x.Text)
                    .FirstOrDefault();

                rv.LocalReport.SetParameters(new ReportParameter("Decl_Text", DeclText));
            }
            rv.LocalReport.Refresh();
            return rv;
        }

        public ReportViewer formSubDividend(string SPVRequestOrderId)
        {
            ReportViewer rv = new ReportViewer();
            rv.LocalReport.DisplayName = "ut_sub_dividend";
            rv.LocalReport.ReportPath = Path.Combine("RDLC", "Sub-Reports", rv.LocalReport.DisplayName + ".rdlc");
            rv.LocalReport.SetParameters(new ReportParameter("FundName", "123"));

            var ds = new ds_ut_sub_dividendTableAdapter().GetData(SPVRequestOrderId).CopyToDataTable();
            if (ds != null && ds.Rows.Count > 0)
            {
                var data = new ReportDataSource
                {
                    Name = "ds_prc_ut_sub_dividend",
                    Value = ds
                };
                rv.LocalReport.DataSources.Add(data);
            }

            rv.LocalReport.Refresh();
            return rv;
        }

        public ReportViewer formSubNoticeSwitching()
        {
            ReportViewer rv = new ReportViewer();
            rv.LocalReport.DisplayName = "ut_sub_imp_notice_switching";
            rv.LocalReport.ReportPath = Path.Combine("RDLC", "Sub-Reports", rv.LocalReport.DisplayName + ".rdlc");
            var ds = new UTOrderFormStaticContentTableAdapter().GetData();
            if (ds.Rows.Count > 0)
            {
                var NoticeSwitching = ds
                    .Where(x =>
                        x.FormSection.Equals("IMPT_NOTICE_ON_SWITCHING") &&
                        x.IndexNo.Equals("00010"))
                    .Select(x => x.Text)
                    .FirstOrDefault();

                rv.LocalReport.SetParameters(new ReportParameter("Imp_Notice_Switching_Text", NoticeSwitching));
            }
            rv.LocalReport.Refresh();
            return rv;
        }
        #endregion for testing purpose
    }
}
