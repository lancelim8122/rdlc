﻿using Microsoft.Reporting.WebForms;
using  RDLC_PDF_Generator.BLL.MainForms;
using  RDLC_PDF_Generator.Datasets.WMSDataSetTableAdapters;
using  RDLC_PDF_Generator.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.Linq;
using WMS.Common;

namespace  RDLC_PDF_Generator.BLL
{
    public static class MainReportService
    {
        static string strCreatedDate;
        static string strCreatedTime;

        public static DocumentRespondModel GeneratePDF(string RequestID, string SessionID)
        {
            var result = new DocumentRespondModel();
            try
            {
                var rv = new ReportViewer();
                rv.LocalReport.EnableExternalImages = true;
                var sectionNo = 0;
                var currentDt = DateTime.Now;
                strCreatedDate = currentDt.ToString("dd MMM yyyy");
                strCreatedTime = currentDt.ToString("dd MMM yyyy, h:mmtt");
                var julianCalendar = new JulianCalendar().ToDateTime(currentDt.Year, currentDt.Month, currentDt.Day, currentDt.Hour, currentDt.Minute, currentDt.Second, currentDt.Millisecond);

                var dsReqOrder = new SPVRequestOrderTableAdapter().GetData(RequestID);
                if(dsReqOrder != null && dsReqOrder.Rows.Count > 0)
                {
                    var dtCustomer = formAgreementSignSection(result, RequestID);
                    var pmtType = dsReqOrder.Rows[0]["PaymentType"].ToString();
                    var transactionType = dsReqOrder.Rows[0]["OrderType"].ToString();

                    switch (transactionType)
                    {
                        case "DIV_UPD": //Dividend instruction
                            new DividendMainForm().formManageDividendInstructionMainForm(RequestID, dtCustomer, rv, sectionNo);
                            break;
                        case "CANCEL": // Cancellation
                            new CancellationMainForm().formCancellationMainForm(RequestID, dtCustomer, rv, sectionNo);
                            break;
                        case "RIS_UPD": //RIS Update
                            new RISEditMainForm().formRISEditMainForm(RequestID, dtCustomer, rv, sectionNo);
                            break;
                        case "RIS_TERM": //RIS Termination
                            new RISTerminationMainForm().formRISTerminationMainForm(RequestID, dtCustomer, rv, sectionNo);
                            break;
                    }
                    assignCommonValue(rv, RequestID, dtCustomer);

                    result.PDFFileBytes = new PDFGenerator().SavePDF(rv);
                    result.DocumentId = "UT" + ("UserIDFromSPVSession").Substring(0, 6) + julianCalendar.ToString("yyyyddd") + currentDt.ToString("HHmmss");                    
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }

        static void assignCommonValue(ReportViewer rv, string RequestID, DataTable dtCustomer)
        {
            var DeclText = "--";
            var Agreement_Text = "--";
            var TNC_Text = "--";

            var ds = new UTOrderFormStaticContentTableAdapter().GetData();
            if (ds != null && ds.Rows.Count > 0)
            {
                DeclText = ds.OrderBy(x => x.IndexNo)
                    .Where(x => x.FormSection.Equals("DECLARATION"))
                    .Select(x => x.Text).FirstOrDefault() ?? "--";

                Agreement_Text = ds.OrderBy(x => x.IndexNo)
                    .Where(x => x.FormSection.Equals("AGREEMENT"))
                    .Select(x => x.Text).FirstOrDefault() ?? "--";

                TNC_Text = ds.OrderBy(x => x.IndexNo)
                    .Where(x => x.FormSection.Equals("TERMS_AND_COND"))
                    .Select(x => x.Text).FirstOrDefault() ?? "--";
            }

            rv.LocalReport.SetParameters(new ReportParameter("Agreement_Text", Agreement_Text));
            rv.LocalReport.SetParameters(new ReportParameter("Decl_Text", DeclText));
            rv.LocalReport.SetParameters(new ReportParameter("TNC_Text", TNC_Text));
            rv.LocalReport.SetParameters(new ReportParameter("CreatedDate", strCreatedDate));
            rv.LocalReport.SetParameters(new ReportParameter("CreatedTime", strCreatedTime));

            rv.LocalReport.DataSources.Add(new ReportDataSource
            {
                Name = "ds_StaticContent",
                Value = ds.CopyToDataTable()
            });

            var subReports = new SubReportService(RequestID, dtCustomer);
            rv.LocalReport.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetAgreementSignSubDataSource);
            rv.LocalReport.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetDeclarationSubDataSource);
            rv.LocalReport.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetTNCSubDataSource);

            rv.LocalReport.Refresh();
        }

        static DataTable formAgreementSignSection(DocumentRespondModel result, string RequestID)
        {
            var dtCustomer = new DataTable();
            dtCustomer.Columns.Add("CustomerName");
            dtCustomer.Columns.Add("SignatureParamName");
            var dsCustCIFNo = new SPVRequestCustomerCIFNoTableAdapter().GetData(RequestID);
            if (dsCustCIFNo != null && dsCustCIFNo.Rows.Count > 0)
            {
                int count = 0;
                var drCust = dtCustomer.NewRow();
                foreach (DataRow dr in dsCustCIFNo.Rows)
                {
                    drCust["CustomerName"] = "CustomerName" + count; // To be replaced and should be mapped from Cache.CustomerInfo
                    drCust["SignatureParamName"] = "SignParam" + count;

                    if (count == 0) // Taking first record as date time created for the creation time for investment form
                    {
                        strCreatedDate = Convert.ToDateTime(dr["CreatedTime"]).ToString("dd MMM yyyy");
                        strCreatedTime = Convert.ToDateTime(dr["CreatedTime"]).ToString("dd MMM yyyy, h:mmtt");
                    }

                    dtCustomer.Rows.Add(drCust);
                    drCust = dtCustomer.NewRow();
                    count++;
                }
                dtCustomer.AcceptChanges();

                count = 0;

                result.SignaturePositions = new List<string>();
                var offset = ConfigurationManager.AppSettings["signBoxOffSet"].ToString();
                var width = ConfigurationManager.AppSettings["signBoxWidth"].ToString();
                var height = ConfigurationManager.AppSettings["signBoxHeight"].ToString();

                foreach (DataRow dr in dtCustomer.Rows)
                {
                    result.SignaturePositions.Add("(name=" + dr["CustomerName"].ToString() + "|searchText=" + dr["SignatureParamName"].ToString() + "|offset=" + offset + "|width=" + width + "|height=" + height + "|type=formfield|subtype|signature|required=true|lock_after_sign=all_editfields|archiveAction=lock_all_if_signed)");
                    count++;
                }
            }
            return dtCustomer;
        }
    }
}