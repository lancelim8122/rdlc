﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace  RDLC_PDF_Generator.Models
{
    public class DocumentRespondModel
    {
        public string DocumentId { get; set; }
        public byte[] PDFFileBytes { get; set; }
        public List<string> SignaturePositions { get; set; }
    }
}
