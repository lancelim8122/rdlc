﻿using Microsoft.Reporting.WebForms;
using  RDLC_PDF_Generator.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;

namespace WMS.Common
{
    public class PDFGenerator
    {
        public byte[] SavePDF(ReportViewer viewer)
        {
            var deviceInfo = @"<DeviceInfo>
                    <EmbedFonts>None</EmbedFonts>
                   </DeviceInfo>";
            byte[] Bytes = viewer.LocalReport.Render(format: "PDF", deviceInfo: deviceInfo);
            var fileName = viewer.LocalReport.DisplayName + ".pdf";
            File.WriteAllBytes(fileName, Bytes);
            return Bytes;
        }
    }
}