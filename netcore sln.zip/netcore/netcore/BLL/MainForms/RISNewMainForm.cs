﻿using Microsoft.Reporting.NETCore;
using RIMS.Common;
using RIMS.Datasets.WMSDatasetTableAdapters;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RIMS.BLL.MainForms
{
    class RISNewMainForm
    {
        public void formRISNewMainForm(string SPVRequestId, DataTable dtCustomer, LocalReport rv, int sectionNo, string sessionId, string entityNumber)
        {
            var utility = new Utility();
            rv.DisplayName = "ut_form_ris_setup";
            rv.ReportPath = utility.getProjectFilePath(Path.Combine("RDLC", rv.DisplayName + ".rdlc"));

            var subReports = new SubReportService(SPVRequestId, dtCustomer, sessionId, entityNumber);
            var add_decl = string.Empty;
            var IMPT_NOTE_CPFIS_SAQ_Text = string.Empty;
            var ds_StaticContent = subReports.getStaticContent();
            if (ds_StaticContent != null && ds_StaticContent.Rows.Count > 0)
            {
                add_decl = ds_StaticContent.AsEnumerable()
                    .Where(x => x.Field<string>("FormSection").Equals("ADD_DECL_FOR_SUBS_AND_SWT"))
                    .Select(x => x.Field<string>("Text").ToString())
                    .FirstOrDefault();

                IMPT_NOTE_CPFIS_SAQ_Text = ds_StaticContent.AsEnumerable()
                    .Where(x => x.Field<string>("FormSection").Equals("IMPT_NOTE_CPFIS_SAQ"))
                    .Select(x => x.Field<string>("Text").ToString())
                    .FirstOrDefault();
            }

            var payment_Type = string.Empty;
            var RISInstruction = string.Empty;
            var ds_Req_Order = subReports.ds_Req_Order_TableAdapter.GetData(SPVRequestId);
            if (ds_Req_Order != null && ds_Req_Order.Rows.Count > 0)
            {
                payment_Type = ds_Req_Order.AsEnumerable()
                    .Select(x => x.PaymentType)
                    .FirstOrDefault();

                RISInstruction = ds_Req_Order.AsEnumerable()
                    .Select(x => x.RISDividendInstruction)
                    .FirstOrDefault();
            }

            rv.SetParameters(new ReportParameter("payment_type", payment_Type));
            rv.SetParameters(new ReportParameter("RISInstruction", RISInstruction));
            rv.SetParameters(new ReportParameter("Add_Decl_Text", add_decl));
            rv.SetParameters(new ReportParameter("IMPT_NOTE_CPFIS_SAQ_Text", IMPT_NOTE_CPFIS_SAQ_Text));

            var path = utility.getImageFilePath(Path.Combine("Image", "Checked.jpg"));
            rv.SetParameters(new ReportParameter("CheckBoxImgUrl", path));
            rv.SetParameters(new ReportParameter("checkbox_html", path));

            #region section number assignation
            sectionNo++;
            rv.SetParameters(new ReportParameter("part_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("CRS_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("UTAcct_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("add_decl_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("ris_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("cpf_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("declaration_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("agreement_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("terms_and_cond_SecNo", sectionNo.ToString()));
            #endregion section number assignation

            #region Sub-reports
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetReqOrderSubDataSource);
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.formSubCRS); 
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetUTAccountDetails); 
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetAddDeclarationSubDataSource);
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetCPFSubDataSource);
            #endregion Sub-reports
        }
    }
}
