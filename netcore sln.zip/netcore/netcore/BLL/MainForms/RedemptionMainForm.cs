﻿using Microsoft.Reporting.NETCore;
using RIMS.BLL;
using RIMS.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RDLCDesigner.Controller.Main_Forms
{
    internal class RedemptionMainForm
    {
        internal void formRedemptionMainForm(string SPVRequestId, DataTable dtCustomer, LocalReport rv, int sectionNo, string sessionId, string entityNumber)
        {
            var utility = new Utility();
            rv.DisplayName = "ut_form_redemption";
            rv.ReportPath = utility.getProjectFilePath(Path.Combine("RDLC", rv.DisplayName + ".rdlc"));

            #region section number assignation
            sectionNo++;
            rv.SetParameters(new ReportParameter("part_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("UTAcct_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("redemption_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("declaration_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("agreement_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("terms_and_cond_SecNo", sectionNo.ToString()));
            #endregion section number assignation

            #region Sub-reports
            var subReports = new SubReportService(SPVRequestId, dtCustomer, sessionId, entityNumber);
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetParticipantsSubDataSource);
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetUTAccountDetails);
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetRedemptionDetailsSubDataSource);
            #endregion Sub-reports
        }
    }
}
