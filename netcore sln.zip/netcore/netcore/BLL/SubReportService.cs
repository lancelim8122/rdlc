﻿using Microsoft.Reporting.NETCore;
using RIMS.CacheService;
using RIMS.Common;
using RIMS.Datasets;
using RIMS.Datasets.WMSDatasetTableAdapters;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;

namespace RIMS.BLL
{
    internal class SubReportService
    {
        string EntityNumber;
        string SessionId;
        string RequestId;
        DataTable dtCustomer;
        DataTable ds_StaticContent;
        UTOrderFormStaticContentTableAdapter ds_StaticContent_TableAdapter = new UTOrderFormStaticContentTableAdapter();
        ds_ut_sub_dividendTableAdapter ds_SubDividend_TableAdapter = new ds_ut_sub_dividendTableAdapter();
        ds_ut_sub_cancellationTableAdapter ds_SubCancellation_TableAdapter = new ds_ut_sub_cancellationTableAdapter();
        internal Req_OrderTableAdapter ds_Req_Order_TableAdapter = new Req_OrderTableAdapter();
        Req_Order_HistTableAdapter ds_Req_Order_History_TableAdapter = new Req_Order_HistTableAdapter();
        SPVDeclarationCRSTableAdapter ds_SPVDeclarationCRS_TableAdapter = new SPVDeclarationCRSTableAdapter();
        ds_RedemptionDetailsTableAdapter ds_RedemptionDetailsTableAdapter = new ds_RedemptionDetailsTableAdapter();
        ds_Agreement_BankOfficerTableAdapter ds_Agreement_BankOfficerTableAdapter = new ds_Agreement_BankOfficerTableAdapter();
        internal SubReportService() { }

        internal SubReportService(string mainRequestId, DataTable mainDtCustomer, string mainSessionId, string entityNumber)
        {
            RequestId = mainRequestId;
            dtCustomer = mainDtCustomer;
            overrideTableAdapterConnectionString();
            ds_StaticContent = ds_StaticContent_TableAdapter.GetData();
            SessionId = mainSessionId;
            EntityNumber = entityNumber;
        }

        internal void SetAgreementSignSubDataSource(object sender, SubreportProcessingEventArgs e)
        {
            if (dtCustomer != null && dtCustomer.Rows.Count > 0)
            {
                e.DataSources.Add(new ReportDataSource
                {
                    Name = "ds_agreement_signature",
                    Value = dtCustomer
                });
            }

            var dt_bankOfficer = ds_Agreement_BankOfficerTableAdapter.GetData(SessionId);
            if(dt_bankOfficer != null && dt_bankOfficer.Rows.Count > 0)
            {
                e.DataSources.Add(new ReportDataSource
                {
                    Name = "ds_agreement_bankOfficer",
                    Value = dt_bankOfficer
                });
            }
        }

        internal void SetFormManageDivInsSubDataSource(object sender, SubreportProcessingEventArgs e)
        {
            var ds = ds_SubDividend_TableAdapter.GetData(RequestId);
            if (ds != null && ds.Rows.Count > 0)
            {
                e.DataSources.Add(new ReportDataSource
                {
                    Name = "ds_prc_ut_sub_dividend",
                    Value = ds.CopyToDataTable()
                });
            }

            e.DataSources.Add(new ReportDataSource
            {
                Name = "ds_StaticContent",
                Value = ds_StaticContent
            });
        }

        internal void SetFormSubCancellationSubDataSource(object sender, SubreportProcessingEventArgs e)
        {
            var ds = ds_SubCancellation_TableAdapter.GetData(RequestId);
            if (ds != null && ds.Rows.Count > 0)
            {
                e.DataSources.Add(new ReportDataSource
                {
                    Name = "ds_prc_sub_cancellation",
                    Value = ds.CopyToDataTable()
                });
            }
        }

        internal void SetAddDeclarationSubDataSource(object sender, SubreportProcessingEventArgs e)
        {
            e.DataSources.Add(new ReportDataSource
            {
                Name = "ds_StaticContent_AddDeclaration",
                Value = ds_StaticContent
            });
        }

        internal void SetCPFSubDataSource(object sender, SubreportProcessingEventArgs e)
        {
            e.DataSources.Add(new ReportDataSource
            {
                Name = "ds_StaticContent",
                Value = ds_StaticContent
            });
        }

        internal void SetDeclarationSubDataSource(object sender, SubreportProcessingEventArgs e)
        {
            e.DataSources.Add(new ReportDataSource
            {
                Name = "ds_StaticContent_Declaration",
                Value = ds_StaticContent
            });
        }

        internal void SetImpNoticeSwitchingSubDataSource(object sender, SubreportProcessingEventArgs e)
        {
            e.DataSources.Add(new ReportDataSource
            {
                Name = "ds_StaticContent_impNotice_Switching",
                Value = ds_StaticContent
            });
        }

        internal void SetTNCSubDataSource(object sender, SubreportProcessingEventArgs e)
        {
            e.DataSources.Add(new ReportDataSource
            {
                Name = "ds_StaticContent_TNC",
                Value = ds_StaticContent
            });
        }

        internal void SetReqOrderSubDataSource(object sender, SubreportProcessingEventArgs e)
        {
            var ds = ds_Req_Order_TableAdapter.GetData(RequestId);
            if (ds != null && ds.Rows.Count > 0)
            {
                e.DataSources.Add(new ReportDataSource
                {
                    Name = "ds_Req_Order",
                    Value = ds
                });
            }
        }

        internal void SetReqOrderHistSubDataSource(object sender, SubreportProcessingEventArgs e)
        {
            var ds = ds_Req_Order_History_TableAdapter.GetData(RequestId);
            if (ds != null && ds.Rows.Count > 0)
            {
                e.DataSources.Add(new ReportDataSource
                {
                    Name = "ds_Req_Order_Hist",
                    Value = ds
                });
            }
        }

        internal void SetUTAccountDetails(object sender, SubreportProcessingEventArgs e)
        {
            var ds_UTAcctDetails = new WMSDataset().ds_UTAccountDetails;
            var dr_UTAcctDetails = ds_UTAcctDetails.NewRow();
            ds_UTAcctDetails.Rows.Add(dr_UTAcctDetails);
            ds_UTAcctDetails.AcceptChanges();

            var CacheModel = retrieveCacheData(SessionId, EntityNumber);
            if (CacheModel != null && CacheModel.Cache != null &&
                CacheModel.Cache.AccountInfo != null && CacheModel.Cache.AccountInfo.Count > 0)
            {
                var rowCount = 0;
                ds_UTAcctDetails.Clear();
                while (rowCount < CacheModel.Cache.AccountInfo.Count)
                {
                    dr_UTAcctDetails["AccType"] = !string.IsNullOrWhiteSpace(CacheModel.Cache.AccountInfo[rowCount].AccType.ToString()) ? CacheModel.Cache.AccountInfo[rowCount].AccType.ToString() : "--";
                    dr_UTAcctDetails["OPTIN"] = !string.IsNullOrWhiteSpace(CacheModel.Cache.AccountInfo[rowCount].OptIneStatement.ToString()) ? CacheModel.Cache.AccountInfo[rowCount].OptIneStatement.ToString() : "--"; ;
                    dr_UTAcctDetails["SIGNCOND"] = !string.IsNullOrWhiteSpace(CacheModel.Cache.AccountInfo[rowCount].SigningCondition.ToString()) ? CacheModel.Cache.AccountInfo[rowCount].SigningCondition.ToString() : "--";
                    dr_UTAcctDetails["MAILADDR"] = !string.IsNullOrWhiteSpace(CacheModel.Cache.AccountInfo[rowCount].DeliverableMailingAddress.ToString()) ? CacheModel.Cache.AccountInfo[rowCount].DeliverableMailingAddress.ToString() : "--";

                    ds_UTAcctDetails.Rows.Add(dr_UTAcctDetails);
                    ds_UTAcctDetails.AcceptChanges();

                    dr_UTAcctDetails = ds_UTAcctDetails.NewRow();
                    rowCount++;
                }
            }

            e.DataSources.Add(new ReportDataSource
            {
                Name = "ds_UTAccountDetails",
                Value = ds_UTAcctDetails
            });
        }

        internal void SetParticipantsSubDataSource(object sender, SubreportProcessingEventArgs e)
        {
            var dsParticipants = new DataTable();
            dsParticipants.Columns.Add("Name");
            dsParticipants.Columns.Add("IdNo");
            dsParticipants.Columns.Add("Nationality");
            dsParticipants.Columns.Add("Gender");
            dsParticipants.Columns.Add("DateOfBirth");
            dsParticipants.Columns.Add("CountryOfBirth");
            dsParticipants.Columns.Add("EmailAddress");
            dsParticipants.Columns.Add("MobileContactNo");
            dsParticipants.Columns.Add("HomeContactNo");
            dsParticipants.Columns.Add("OfficeContactNo");
            dsParticipants.Columns.Add("Occupation");
            var drParticipants = dsParticipants.NewRow();
            dsParticipants.Rows.Add(drParticipants);
            dsParticipants.AcceptChanges();
            var CacheModel = retrieveCacheData(SessionId, EntityNumber);
            if (CacheModel != null && CacheModel.Cache != null && CacheModel.Cache.CustomerInfo != null && CacheModel.Cache.CustomerInfo.Count > 0)
            {
                dsParticipants.Clear();
                foreach (var custInfo in CacheModel.Cache.CustomerInfo)
                {
                    drParticipants = dsParticipants.NewRow();

                    var CustomerName = custInfo.Name1.ToString() + " " + custInfo.Name2.ToString();
                    if (custInfo.MainApplicant != null && !string.IsNullOrWhiteSpace(custInfo.MainApplicant)
                        && custInfo.MainApplicant.ToString().Trim().ToUpper().Equals("Y"))
                    {
                        CustomerName += " - Main Applicant";
                    }
                    drParticipants["Name"] = CustomerName;
                    drParticipants["IdNo"] = custInfo.IDNo.ToString();
                    drParticipants["Nationality"] = custInfo.Nationality.ToString(); // code, to be retrieved from db
                    drParticipants["Gender"] = custInfo.Gender.ToString(); // code, to be retrieved from db
                    drParticipants["DateOfBirth"] = custInfo.Dob.ToString();
                    drParticipants["CountryOfBirth"] = custInfo.CountryOfBirth.ToString();
                    drParticipants["EmailAddress"] = custInfo.Email.ToString();
                    drParticipants["MobileContactNo"] = custInfo.Phone.ToString();
                    drParticipants["HomeContactNo"] = custInfo.HomePhone.ToString();
                    drParticipants["OfficeContactNo"] = custInfo.OfficePhone.ToString();
                    //drParticipants["Occupation"] = custInfo.Occupation.ToString(); // code, to be retrieved from db
                    drParticipants["Occupation"] = "Occupation Test";

                    dsParticipants.Rows.Add(drParticipants);
                    dsParticipants.AcceptChanges();
                }
            }

            e.DataSources.Add(new ReportDataSource
            {
                Name = "ds_Participants_Info",
                Value = dsParticipants
            });
        }

        internal void SetRedemptionDetailsSubDataSource(object sender, SubreportProcessingEventArgs e)
        {
            var ds_RedemptionDetails = ds_RedemptionDetailsTableAdapter.GetData(RequestId);
            if(ds_RedemptionDetails != null && ds_RedemptionDetails.Rows.Count > 0)
            {
                e.DataSources.Add(new ReportDataSource
                {
                    Name = "ds_RedemptionDetails",
                    Value = ds_RedemptionDetails
                });
            }
        }
        
        internal void formSubCRS(object sender, SubreportProcessingEventArgs e)
        {
            var ds = ds_SPVDeclarationCRS_TableAdapter.GetData(SessionId);
            
            if (ds != null && ds.Rows.Count > 0)
            {
                ds.Columns.Add("CustomerName1");
                ds.Columns.Add("CustomerName2");
                ds.AcceptChanges();
                var CacheModel = retrieveCacheData(SessionId, EntityNumber);
                if (CacheModel != null && CacheModel.Cache != null &&
                CacheModel.Cache.AccountInfo != null && CacheModel.Cache.AccountInfo.Count > 0)
                {

                }
                e.DataSources.Add(new ReportDataSource
                {
                    Name = "ds_SPVDeclarationCRS",
                    Value = ds.CopyToDataTable()
                });
            }
        }

        internal LocalReport formSubsDetails(string requestId)
        {
            var payment_type = string.Empty;
            var RISInstruction = string.Empty;

            LocalReport rv = new LocalReport();
            //rv.LocalReport.EnableExternalImages = true;
            rv.DisplayName = "Subscription Details (Lump-Sum Only)";
            rv.ReportPath = Path.Combine("Reports", rv.DisplayName + ".rdlc");
            var ds = ds_Req_Order_TableAdapter.GetData(requestId);
            if (ds != null && ds.Rows.Count > 0)
            {
                payment_type = ds
                    .Select(x => x.PaymentType)
                    .FirstOrDefault();

                RISInstruction = ds
                    .Select(x => x.RISDividendInstruction)
                    .FirstOrDefault();

                rv.DataSources.Add(new ReportDataSource
                {
                    Name = "DataSet1",
                    Value = ds
                });
            }

            rv.SetParameters(new ReportParameter("payment_type", payment_type));
            rv.SetParameters(new ReportParameter("RISInstruction", RISInstruction));
            rv.Refresh();
            return rv;
        }

        internal LocalReport formSubRIS(string requestId)
        {
            var reqType = string.Empty;
            var payment_type = string.Empty;
            var RISInstruction = string.Empty;

            LocalReport rv = new LocalReport();
            var ds = ds_Req_Order_TableAdapter.GetData(requestId);

            if (ds != null && ds.Rows.Count > 0)
            {
                reqType = ds
                    .Select(x => x.PaymentType)
                    .FirstOrDefault();

                payment_type = ds
                    .Select(x => x.PaymentType)
                    .FirstOrDefault();

                RISInstruction = ds
                    .Select(x => x.RISDividendInstruction)
                    .FirstOrDefault();

                switch (reqType)
                {
                    case "RIS_UPD":
                        rv.DisplayName = "Regular Investment Scheme (RIS)_Updated";
                        break;
                    case "RIS_TERM":
                        rv.DisplayName = "Regular Investment Scheme (RIS)_Terminated";
                        break;
                    default:
                        rv.DisplayName = "Regular Investment Scheme (RIS)_New";
                        break;
                }

                rv.DataSources.Add(new ReportDataSource
                {
                    Name = "DataSet1",
                    Value = ds
                });
            }

            rv.SetParameters(new ReportParameter("payment_type", payment_type));
            rv.SetParameters(new ReportParameter("RISInstruction", RISInstruction));

            rv.ReportPath = Path.Combine("Reports", rv.DisplayName + ".rdlc");
            rv.Refresh();
            return rv;
        }

        internal LocalReport formSubRedemp(string requestId)
        {
            var InvestType = string.Empty;

            LocalReport rv = new LocalReport();
            rv.DisplayName = "Redemption Details";
            rv.ReportPath = Path.Combine("Reports", rv.DisplayName + ".rdlc");

            var ds = ds_Req_Order_TableAdapter.GetData(requestId);
            if (ds != null && ds.Rows.Count > 0)
            {
                InvestType = ds
                    .Select(x => x.InvestmentType)
                    .FirstOrDefault();

                rv.DataSources.Add(new ReportDataSource
                {
                    Name = "DataSet1",
                    Value = ds
                });
            }

            rv.SetParameters(new ReportParameter("InvestType", InvestType));
            rv.Refresh();
            return rv;
        }

        void overrideTableAdapterConnectionString()
        {
            string connString = ConfigurationManager.ConnectionStrings["WMSDataSetConnectionString"].ToString();

            ds_StaticContent_TableAdapter.Connection.ConnectionString = connString;
            ds_SubDividend_TableAdapter.Connection.ConnectionString = connString;
            ds_SubCancellation_TableAdapter.Connection.ConnectionString = connString;
            ds_Req_Order_TableAdapter.Connection.ConnectionString = connString;
            ds_Req_Order_History_TableAdapter.Connection.ConnectionString = connString;
            ds_SPVDeclarationCRS_TableAdapter.Connection.ConnectionString = connString;
            ds_RedemptionDetailsTableAdapter.Connection.ConnectionString = connString;
            ds_Agreement_BankOfficerTableAdapter.Connection.ConnectionString = connString;
        }

        internal dynamic retrieveCacheData(string sessionId, string entityNumber)
        {
            var cacheKeyName = string.Format("{0}_{1}", sessionId, entityNumber);

            var cacheService = new CacheService<byte[]>();

            var cacheData = cacheService.CheckIfCacheLists(cacheKeyName);

            return cacheData;
        }

        internal DataTable getStaticContent()
        {
            return ds_StaticContent;
        }
    }
}
